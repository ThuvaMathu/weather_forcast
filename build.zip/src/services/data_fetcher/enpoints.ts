// URL for dev purpose
export const weatherURL = `http://localhost:8080/api/demo/weather`;
export const giphyURL = `http://localhost:8080/api/giphy`;

//URL for build purpose
// export const weatherURL = `/api/weather`;
// export const giphyURL = `/api/giphy`;
